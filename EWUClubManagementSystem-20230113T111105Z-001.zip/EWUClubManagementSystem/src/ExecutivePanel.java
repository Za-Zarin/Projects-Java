
public abstract class ExecutivePanel extends Member {
	
	ExecutivePanel() {
		
	}

	ExecutivePanel(String name, String id, String department, String position, String phoneNum, String bloodGrp,
			String email, int noOfSemester, boolean isAdmin) {
		super(name, id, department, position, phoneNum, bloodGrp, email, noOfSemester, isAdmin);
	}
}
