/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagmentsystem;
import static com.sun.java.accessibility.util.AWTEventMonitor.addActionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
public class Pannel extends WindowAdapter {

	JFrame pnl;
	
	public Pannel() {
		pnl=new JFrame("MainPanel");
		JLabel label1 = new JLabel("Hospital Managment System");
		label1.setFont(new Font("Helvetica", Font.BOLD, 27));
		label1.setBounds(246, 11, 478, 33);
               pnl.addWindowListener(this); 
		pnl.add(label1);
		
		JButton button1 = new JButton("Patient");
	
		button1.setBounds(168, 161, 99, 36);
		pnl.add(button1);
                button1.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        try {
                            pnl.setVisible(false);
                            Patient crse =new Patient();
                        } catch (IOException ex) {
                            Logger.getLogger(Pannel.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }); 
                
             //    pnl.setVisible(false);
                             
	        
		
		JButton button2 = new JButton("Doctor");
		
		button2.setBounds(601, 159, 98, 36);
		pnl.add(button2);
                 button2.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                	  pnl.setVisible(false);
                           try {
                               Doctor nw=new Doctor();
                           } catch (IOException ex) {
                               Logger.getLogger(Pannel.class.getName()).log(Level.SEVERE, null, ex);
                           }
	               }  
	            }); 
		
		JButton button3 = new JButton("Staff");
		button3.setBounds(353, 160, 176, 36);
		pnl.add(button3);
                button3.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        pnl.setVisible(false);
                        try {
                            Staff std=new Staff();
                        } catch (IOException ex) {
                            Logger.getLogger(Pannel.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }); 
		
		
		JButton button5 = new JButton("Hospital Expense Calculation");
		button5.setBounds(262, 222, 200, 36);
		pnl.add(button5);
                button5.addActionListener(new ActionListener() {  
                       @Override
	               public void actionPerformed(ActionEvent e) {       
	                       pnl.setVisible(false);
                             Payment py=new Payment();
	                 }
	                      
	               } );
               
		
		JButton button6 = new JButton("Notice");
		button6.setBounds(500, 222, 129, 36);
		pnl.add(button6);
                 button6.addActionListener(new ActionListener() {  
                       @Override
	               public void actionPerformed(ActionEvent e) {       
	                       pnl.setVisible(false);
                               Notice ntc=new Notice();
	                 }
	                      
	               } );
                 
	                     
	
	
               
                JButton button8 = new JButton("Sign out!");
		button8.setBounds(384, 390, 105, 36);
		pnl.add(button8);
                   button8.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) { 
  
    int n = JOptionPane.showOptionDialog(null,"Do you really want to signout?","Warning!",JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE,null,null,null);  
    if(n==0){
         pnl.setVisible(false);
         startmenu stt=new startmenu();
    }
    
	                 }
	                      
	               } ); 
	        
		
		pnl.setSize(901,499); //frame
		pnl.setLayout(null);  //frame
		pnl.setVisible(true);  //frame
		pnl.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); 	
	}
        @Override
                public void windowClosing(WindowEvent e) {  
    int a=JOptionPane.showConfirmDialog(pnl,"Are you sure you want to Exit?");  
if(a==JOptionPane.YES_OPTION){  
    pnl.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
}  
} 
}


