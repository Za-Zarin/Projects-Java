/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagmentsystem;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import static java.lang.System.in;
import java.util.logging.*;
import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;




public class Staff {
    private String StaffName;
    private String StaffId;
    private double PhoneNumber;
    private double Salary;
    private String department;
    

    JFrame std;
public    Staff() throws FileNotFoundException, IOException{
                std=new JFrame("Staff Management");
		JLabel label = new JLabel("Staff Management");
		label.setFont(new Font("Helvetica", Font.BOLD, 20));
		label.setBounds(375, -5, 246, 48);
		 std.add(label);
                 JTextPane textPane = new JTextPane();
		textPane.setBounds(564, 107, 285, 263);
		 std.add(textPane);
		
		JButton button = new JButton("Add");
		 button.setBounds(56, 224, 89, 23);
		 std.add(button);
                  button.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                   std.setVisible(false);
                           addStaff s=new addStaff();                            //done
                           
	                 }
	                      
	               } ); 
                  
                                                                   //scroll pan viweing code
                  JScrollPane scrollPane = new JScrollPane();
		 scrollPane.setBounds(229, 107, 285, 263);
		 std.add(scrollPane);
                 
                 final DefaultListModel<String> l1 = new DefaultListModel<>();  
       
                 FileReader fw=null;
		BufferedReader bf=null;
		try {
			fw=new FileReader("StuffName.txt");
			bf= new BufferedReader(fw);
			String line="";
			while((line=bf.readLine())!=null) {
                            if(!line.equals("deleted"))
				l1.addElement(line);
                            
                            
			}
			
		}finally {
			fw.close();
			    bf.close();
		}
         
           final JList<String> list = new JList<>(l1);
		scrollPane.setViewportView(list);
                                             
		                                                         //show details code
		JButton button1 = new JButton("Show Details");
		button1.setBounds(41, 173, 116, 23);
		 std.add(button1);
               button1 .addActionListener(new ActionListener() {           
	               public void actionPerformed(ActionEvent e) {       
	                     
                                    if (list.getSelectedIndex() != -1) {                       
                      String  selected =list.getSelectedValue(); 
                                     
                       String line2=" ";
                       String line="";
                                int lineno=0;
                                boolean ans=true;
                               FileReader fw=null;
		           BufferedReader bf=null;
		try {
			fw=new FileReader("StaffMain.txt");
			bf= new BufferedReader(fw);
                       
			 String original="Name of Staff : "+selected;
                     
			while((line2=bf.readLine())!=null) {
                            if(line2.equals(original)){
                                ans=false;
                               lineno++;
                            }
                            if(ans==false && lineno<=5){
                                 line=line+"\n"+line2;  // && !line.equals("END")
                                  lineno++;
                            }
				
			}
                        fw.close();
			bf.close();
			
		}              catch (FileNotFoundException ex) {
                                  
                               }        catch (IOException ex) {
                                           
                                        }finally {
			
		} 

                           textPane.setText(line);        
     
                           }
                             
	                 }
	                      
	               } );                                              //show details code
		
		JButton button2 = new JButton("Delete");
		button2.setBounds(56, 272, 89, 23);
		 std.add(button2);
                  button2.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	 int n = JOptionPane.showOptionDialog(null,"Do you really want to Delete?","Warning!",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,null,null,null);  
                       if(n==0)                     
                          if (list.getSelectedIndex() != -1) {                       
                     String  selected = list.getSelectedValue(); 
                       //file writing
                       
                FileWriter fwrite=null;
		BufferedWriter bw=null;
		PrintWriter pw=null;
		
		FileReader fw=null;
		BufferedReader bf=null;
                String content="";
		try {
			fw=new FileReader("StuffName.txt");
			bf= new BufferedReader(fw);
			String line="";
			while((line=bf.readLine())!=null) {
				content+=line+"\n";
			}
                        
                        fw.close();
			bf.close();
			
		} catch (IOException ex) {
                                           
                  }finally {
			
		}
                
                
               
                content=content.replaceAll(selected,"deleted");
                
              //  writing
              
            
		try {
		    // fle= new File();
			 fwrite =new FileWriter("StuffName.txt");
			 bw =new BufferedWriter(fwrite);
			 pw=new PrintWriter(bw);
			pw.println(content);
                        
                        bw.close();
			pw.close();
		}catch (IOException ex) {
                    
                                         }
                       
                              }
                           
                           
	                 
	                      
                       } } ); 
		
		
		
//             JTextField textField = new JTextField();
//		textField.setColumns(10);
//		textField.setBounds(713, 70, 136, 20);
//		 std.add(textField);
		
		JLabel label1 = new JLabel("Staff List");
		label1.setBounds(332, 88, 105, 14);
		 std.add(label1);
		
		JButton button3 = new JButton("<Back");
		button3.setBounds(10, 7, 87, 32);
		 std.add(button3);
                 button3.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                       std.setVisible(false);
                               Pannel pnl=new Pannel();
	                 }
	                      
	               } ); 
	        
		
		JButton button4 = new JButton("Update List");
		button4.setBounds(308, 387, 124, 23);
		 std.add(button4);
                 button4 .addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                     
                                    l1.clear();
                 
                FileReader fw=null;
		BufferedReader bf=null;
		try {
			fw=new FileReader("StuffName.txt");
			bf= new BufferedReader(fw);
			String line="";
			while((line=bf.readLine())!=null) {
                            if(!line.equals("deleted"))
				l1.addElement(line);
			}
                           fw.close();
			   bf.close();
			
		}          catch (FileNotFoundException ex) {
                               Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
                           } catch (IOException ex) {
                               Logger.getLogger(Staff.class.getName()).log(Level.SEVERE, null, ex);
                           }finally {
			  
		}
         
           final JList<String> list = new JList<>(l1);
                
      
                       }} ); 
		
	
                
                std.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		std.setSize(901,499);
		std.setLayout(null);
                std.setVisible(true);
        
        
    }

   
    
    Staff(String StaffName,String Staffid,double PhoneNumber,double salary,String department) {
        this.StaffName = StaffName;
        this.StaffId=Staffid;
        this.PhoneNumber=PhoneNumber;
        this.Salary=salary;
        this.department=department;
    }
     Staff(String Staffid) {       
        this.StaffId=Staffid;
    }

    Staff(String name, String id, String ph, String de, double s3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Staff(String name, String id, double ph, String de, double s3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Staff(String name, String id, int ph, String de) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Staff(String name, int id1, int ph, String de, double s3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Staff(String name, int id1, int ph, double s3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Staff(String name, int id1, int ph, double s3, String de) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getStaffName() {
        return StaffName;
    }
     public String getStaffId() {
        return StaffId;
    }

    public void setStaffName(String StuffName) {
        this.StaffName = StuffName;
    }
     public void setStuffId(String Stuffid) {
        this.StaffId = Stuffid;
    }

    @Override
    public String toString() {
        return "Name of Staff : "+StaffName+"\n"+"Id of Staff : " + getStaffId()+"\n"+"Department :"+department+"\n"+"Phone Number: "+PhoneNumber+
                    "\n"+"Salary  : "+Salary;

    }

}
class addStaff{
    JFrame adc;
    addStaff(){
        adc=new JFrame("Add a Staff");
        adc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		adc.setSize(901,499);
                
		
		adc.setLayout(null);
                adc.setVisible(true);
		
		JLabel lblStaffDetails = new JLabel("Staff Details");
		lblStaffDetails.setFont(new Font("Helvetica", Font.BOLD, 20));
		lblStaffDetails.setBounds(392, 0, 220, 45);
		adc.add(lblStaffDetails);
		
		JLabel lblStaffName = new JLabel("Staff Name :");
		lblStaffName.setBounds(251, 96, 91, 14);
		adc.add(lblStaffName);
		
        JTextField textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(352, 89, 208, 29);
		adc.add(textField);
		
        JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(352, 148, 208, 29);
		adc.add(textField_1);
		
        JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(352, 204, 208, 29);
		adc.add(textField_2);
		
        JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(352, 267, 208, 29);
		adc.add(textField_3);
		
        JTextField textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(352, 330, 208, 29);
		adc.add(textField_4);
//		
		JLabel lblStaffid = new JLabel("Staff Id :");
		lblStaffid.setBounds(251, 155, 91, 14);
		adc.add(lblStaffid);
		
		JLabel lblPhone = new JLabel("Phone Number :");
		lblPhone.setBounds(251, 211, 91, 14);
		adc.add(lblPhone);
		
		JLabel lblsalary = new JLabel("Salary :");
		lblsalary.setBounds(251, 274, 91, 14);
		adc.add(lblsalary);
		
		JLabel lblDepartment = new JLabel("Department :");
		lblDepartment.setBounds(251, 337, 91, 14);
		adc.add(lblDepartment);
                

                
		
		JButton btnNewButton = new JButton("Done");
		btnNewButton.setBounds(417, 397, 89, 23);
		adc.add(btnNewButton);
                btnNewButton.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                     
                           String sname=textField.getText();
                           String id=textField_1.getText();
                           String phone=textField_2.getText();
                           String salary=textField_3.getText();
                           String de=textField_4.getText();
                           //int id1=Integer.parseInt (id);
                           int ph=Integer.parseInt (phone);
                           double s3=Double.parseDouble(salary);
                           
                       Staff c=new Staff(sname,id,ph,s3,de);
                       String print=c.toString();
                           
                FileWriter fwrite=null;
		BufferedWriter bw=null;
		PrintWriter pw=null;
		                                 
                        
		try {
		   
			 fwrite =new FileWriter("StaffMain.txt",true);
			 bw =new BufferedWriter(fwrite);
			 pw=new PrintWriter(bw);
                         pw.println(print);
                         
                         bw.close();
			pw.close();
			
		}          catch (IOException ex) {
                               Logger.getLogger(addStaff.class.getName()).log(Level.SEVERE, null, ex);
                           }finally {
			
		}
              
                
                
                  try {

                         fwrite =new FileWriter("StuffName.txt",true);
			 bw =new BufferedWriter(fwrite);
			 pw=new PrintWriter(bw);
                         pw.println(sname);
			
                         bw.close();
			pw.close();
			
		}          catch (IOException ex) {
                               Logger.getLogger(addStaff.class.getName()).log(Level.SEVERE, null, ex);
                           }finally {
			
		}
            
                             adc.setVisible(false);
                             try{
                                  Staff cf=new Staff();
                             }catch(IOException eee){
                                 
                             }
                            
                       
                           
	                 }
	                      
	               } ); 
                
                
                
                
                
                JButton btnNewButton_2 = new JButton("<Back");
		btnNewButton_2.setBounds(10, 15, 87, 32);
		adc.add(btnNewButton_2);
                btnNewButton_2.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                     adc.setVisible(false);
                             try{
                                Staff cf=new Staff();  
                             }catch(IOException ee){
                                 
                             }
                            
                           
	                 }
	                      
	               } ); 
    }
}

