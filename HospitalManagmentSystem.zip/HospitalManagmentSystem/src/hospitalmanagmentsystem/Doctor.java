/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagmentsystem;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import static java.lang.System.in;
import java.util.logging.*;
import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;




public class Doctor {
    private String DoctorName;
    private String DoctorId;
    private double PhoneNumber;
    private double Salary;
    private String department;
    

    JFrame nw;
public    Doctor() throws FileNotFoundException, IOException{
                nw=new JFrame("Doctor Management");
		JLabel label = new JLabel("Doctor Management");
		label.setFont(new Font("Helvetica", Font.BOLD, 20));
		label.setBounds(375, -5, 246, 48);
		 nw.add(label);
                 JTextPane textPane = new JTextPane();
		textPane.setBounds(564, 107, 285, 263);
		 nw.add(textPane);
		
		JButton button = new JButton("Add");
		 button.setBounds(56, 224, 89, 23);
		 nw.add(button);
                  button.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                   nw.setVisible(false);
                           addDoctor s=new addDoctor();                            //done
                           
	                 }
	                      
	               } ); 
                  
                                                                   //scroll pan viweing code
                  JScrollPane scrollPane = new JScrollPane();
		 scrollPane.setBounds(229, 107, 285, 263);
		 nw.add(scrollPane);
                 
                 final DefaultListModel<String> l1 = new DefaultListModel<>();  
       
                 FileReader fw=null;
		BufferedReader bf=null;
		try {
			fw=new FileReader("DoctorName.txt");
			bf= new BufferedReader(fw);
			String line="";
			while((line=bf.readLine())!=null) {
                            if(!line.equals("deleted"))
				l1.addElement(line);
                            
                            
			}
			
		}finally {
			fw.close();
			    bf.close();
		}
         
           final JList<String> list = new JList<>(l1);
		scrollPane.setViewportView(list);
                                             
		                                                         //show details code
		JButton button1 = new JButton("Show Details");
		button1.setBounds(41, 173, 116, 23);
		 nw.add(button1);
               button1 .addActionListener(new ActionListener() {           
	               public void actionPerformed(ActionEvent e) {       
	                     
                                    if (list.getSelectedIndex() != -1) {                       
                      String  selected =list.getSelectedValue(); 
                                     
                       String line2=" ";
                       String line="";
                                int lineno=0;
                                boolean ans=true;
                               FileReader fw=null;
		           BufferedReader bf=null;
		try {
			fw=new FileReader("DoctorMain.txt");
			bf= new BufferedReader(fw);
                       
			 String original="Name of Doctor : "+selected;
                     
			while((line2=bf.readLine())!=null) {
                            if(line2.equals(original)){
                                ans=false;
                               lineno++;
                            }
                            if(ans==false && lineno<=5){
                                 line=line+"\n"+line2;  // && !line.equals("END")
                                  lineno++;
                            }
				
			}
                        fw.close();
			bf.close();
			
		}              catch (FileNotFoundException ex) {
                                  
                               }        catch (IOException ex) {
                                           
                                        }finally {
			
		} 

                           textPane.setText(line);        
     
                           }
                             
	                 }
	                      
	               } );                                              //show details code
		
		JButton button2 = new JButton("Delete");
		button2.setBounds(56, 272, 89, 23);
		 nw.add(button2);
                  button2.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	 int n = JOptionPane.showOptionDialog(null,"Do you really want to Delete?","Warning!",
            JOptionPane.YES_NO_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE,null,null,null);  
                       if(n==0)                     
                          if (list.getSelectedIndex() != -1) {                       
                     String  selected = list.getSelectedValue(); 
                       //file writing
                       
                FileWriter fwrite=null;
		BufferedWriter bw=null;
		PrintWriter pw=null;
		
		FileReader fw=null;
		BufferedReader bf=null;
                String content="";
		try {
			fw=new FileReader("DoctorName.txt");
			bf= new BufferedReader(fw);
			String line="";
			while((line=bf.readLine())!=null) {
				content+=line+"\n";
			}
                        
                        fw.close();
			bf.close();
			
		} catch (IOException ex) {
                                           
                  }finally {
			
		}
                
                
               
                content=content.replaceAll(selected,"deleted");
                
              //  writing
              
            
		try {
		    // fle= new File();
			 fwrite =new FileWriter("DoctorName.txt");
			 bw =new BufferedWriter(fwrite);
			 pw=new PrintWriter(bw);
			pw.println(content);
                        
                        bw.close();
			pw.close();
		}catch (IOException ex) {
                    
                                         }
                       
                              }
                           
                           
	                 
	                      
                       } } ); 
		
		
		
//             JTextField textField = new JTextField();
//		textField.setColumns(10);
//		textField.setBounds(713, 70, 136, 20);
//		 nw.add(textField);
//		
		JLabel label1 = new JLabel("Doctor List");
		label1.setBounds(332, 88, 105, 14);
		 nw.add(label1);
		
		JButton button3 = new JButton("<Back");
		button3.setBounds(10, 7, 87, 32);
		 nw.add(button3);
                 button3.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                       nw.setVisible(false);
                               Pannel pnl=new Pannel();
	                 }
	                      
	               } ); 
	        
		
		JButton button4 = new JButton("Update List");
		button4.setBounds(308, 387, 124, 23);
		 nw.add(button4);
                 button4 .addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                     
                                    l1.clear();
                 
                FileReader fw=null;
		BufferedReader bf=null;
		try {
			fw=new FileReader("DoctorName.txt");
			bf= new BufferedReader(fw);
			String line="";
			while((line=bf.readLine())!=null) {
                            if(!line.equals("deleted"))
				l1.addElement(line);
			}
                           fw.close();
			   bf.close();
			
		}          catch (FileNotFoundException ex) {
                               Logger.getLogger(Doctor.class.getName()).log(Level.SEVERE, null, ex);
                           } catch (IOException ex) {
                               Logger.getLogger(Doctor.class.getName()).log(Level.SEVERE, null, ex);
                           }finally {
			  
		}
         
           final JList<String> list = new JList<>(l1);
                
      
                       }} ); 
		
		
                
                nw.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		nw.setSize(901,499);
		nw.setLayout(null);
                nw.setVisible(true);
        
        
    }

   
    
    Doctor(String Doctorname,String Doctorid,double Number,double Salary,String department) {
        this.DoctorName = Doctorname;
        this.DoctorId=Doctorid;
        this.PhoneNumber=Number;
        this.Salary=Salary;
        this.department=department;
    }
     Doctor(String Doctorid) {       
        this.DoctorId=Doctorid;
    }

    Doctor(String name, String id, String num, String d1, double s) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Doctor(String dname, String id, String d1, double s, String num) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Doctor(String dname, String id, String d1, double s, int num1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    Doctor(String dname, int docid, String d1, double s, int num1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String DoctorName() {
        return DoctorName;
    }
     public String getDoctorId() {
        return DoctorId;
    }

    public void seDoctorName(String DoctorName) {
        this.DoctorName = DoctorName;
    }
     public void setDoctorId(String Doctorid) {
        this.DoctorId = Doctorid;
    }

    @Override
    public String toString() {
        return "Name of Doctor : "+DoctorName+"\n"+"Id of Doctor : " + getDoctorId()+"\n"+"Department :"+department+"\n"+"Phone Number: "+PhoneNumber+
                    "\n"+"Salary  : "+Salary;

    }

}
class addDoctor{
    JFrame adc;
    addDoctor(){
        adc=new JFrame("Add a Doctor");
        adc.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		adc.setSize(901,499);
                
		
		adc.setLayout(null);
                adc.setVisible(true);
		
		JLabel lblDoctorDetails = new JLabel("Doctor Details");
		lblDoctorDetails.setFont(new Font("Helvetica", Font.BOLD, 20));
		lblDoctorDetails.setBounds(392, 0, 220, 45);
		adc.add(lblDoctorDetails);
		
		JLabel lblDoctorName = new JLabel("Doctor Name :");
		lblDoctorName.setBounds(251, 96, 91, 14);
		adc.add(lblDoctorName);
		
        JTextField textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(352, 89, 208, 29);
		adc.add(textField);
		
        JTextField textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(352, 148, 208, 29);
		adc.add(textField_1);
		
        JTextField textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(352, 204, 208, 29);
		adc.add(textField_2);
//		
        JTextField textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(352, 267, 208, 29);
		adc.add(textField_3);
		
        JTextField textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(352, 330, 208, 29);
		adc.add(textField_4);
		
		JLabel lblDoctorId = new JLabel("Doctor Id :");
		lblDoctorId.setBounds(251, 155, 91, 14);
		adc.add(lblDoctorId);
		
		JLabel lblDepartment = new JLabel("Phone Number :");
		lblDepartment.setBounds(251, 211, 91, 14);
		adc.add(lblDepartment);
		
		JLabel lblSalary = new JLabel("Salary :");
		lblSalary.setBounds(251, 274, 91, 14);
		adc.add(lblSalary);
		
		JLabel lblPhoneNumber = new JLabel("Department : ");
		lblPhoneNumber.setBounds(251, 337, 91, 14);
		adc.add(lblPhoneNumber);
                
                
                
                
                
		
		JButton btnNewButton = new JButton("Done");
		btnNewButton.setBounds(417, 397, 89, 23);
		adc.add(btnNewButton);
                btnNewButton.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                     
                           String dname=textField.getText();
                           String did=textField_1.getText();
                           String dphone=textField_2.getText();
                           String dsalary=textField_3.getText();
                           String ddpt=textField_4.getText();
                           //int id1=Integer.parseInt (id);
                           int ph=Integer.parseInt (dphone);
                           double s3=Double.parseDouble(dsalary);
                           
                       Doctor r= new Doctor(dname,did,ph,s3,ddpt);
                       String print=r.toString();
                           
                FileWriter fwrite=null;
		BufferedWriter bw=null;
		PrintWriter pw=null;
		                                 
                        
		try {
		   
			 fwrite =new FileWriter("DoctorMain.txt",true);
			 bw =new BufferedWriter(fwrite);
			 pw=new PrintWriter(bw);
                         pw.println(print);
                         
                         bw.close();
			pw.close();
			
		}          catch (IOException ex) {
                               Logger.getLogger(addDoctor.class.getName()).log(Level.SEVERE, null, ex);
                           }finally {
			
		}
              
                
                
                  try {

                         fwrite =new FileWriter("DoctorName.txt",true);
			 bw =new BufferedWriter(fwrite);
			 pw=new PrintWriter(bw);
                         pw.println(dname);
			
                         bw.close();
			pw.close();
			
		}          catch (IOException ex) {
                               Logger.getLogger(addDoctor.class.getName()).log(Level.SEVERE, null, ex);
                           }finally {
			
		}
            
                             adc.setVisible(false);
                             try{
                                  Doctor cf=new Doctor();
                             }catch(IOException eee){
                                 
                             }
                            
                       
                           
	                 }
	                      
	               } ); 
                
                
                
                
                
                JButton btnNewButton_2 = new JButton("<Back");
		btnNewButton_2.setBounds(10, 15, 87, 32);
		adc.add(btnNewButton_2);
                btnNewButton_2.addActionListener(new ActionListener() {  
	               public void actionPerformed(ActionEvent e) {       
	                     adc.setVisible(false);
                             try{
                                Doctor cf=new Doctor();  
                             }catch(IOException ee){
                                 
                             }
                            
                           
	                 }
	                      
	               } ); 
    }
}
